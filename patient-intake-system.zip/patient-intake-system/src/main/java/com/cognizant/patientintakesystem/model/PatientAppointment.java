package com.cognizant.patientintakesystem.model;


import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public  class PatientAppointment {
	public String name;
	public Date appointmentDate;
}
