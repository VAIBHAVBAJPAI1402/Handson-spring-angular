package com.cognizant.patientintakesystem.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cognizant.patientintakesystem.model.ClinicCalender;
import com.cognizant.patientintakesystem.model.PatientAppointment;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class PatientService {
	PatientAppointment f = new PatientAppointment();
	public static List<PatientAppointment> patientlist = new ArrayList<>();

	public boolean addAppointment(ClinicCalender calender, PatientAppointment p) {
		if (calender != null) {
			List<PatientAppointment> lst = calender.getPatientAppointment();
			for (PatientAppointment pa : lst) {
				if (pa.appointmentDate.compareTo(p.getAppointmentDate()) == 0) {
					log.info("Appointment cant be scheduled at given date");
					return false;
				}
			}
			patientlist.add(p);
			calender.setPatientAppointment(patientlist);
			return true;
		}
		return false;
	}

	public void viewAllAppointment(ClinicCalender c) {
		for (int i = 0; i < c.getPatientAppointment().size(); i++) {
			log.info(patientlist.get(i).toString());
		}
	}
}
