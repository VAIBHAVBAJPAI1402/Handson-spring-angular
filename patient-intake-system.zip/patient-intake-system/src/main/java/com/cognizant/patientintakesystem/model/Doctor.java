package com.cognizant.patientintakesystem.model;

public enum Doctor {
	Doc1, Doc2, Doc3

}
