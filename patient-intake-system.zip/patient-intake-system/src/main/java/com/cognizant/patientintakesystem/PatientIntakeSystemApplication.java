package com.cognizant.patientintakesystem;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.patientintakesystem.model.ClinicCalender;
import com.cognizant.patientintakesystem.model.PatientAppointment;
import com.cognizant.patientintakesystem.service.PatientService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootApplication
public class PatientIntakeSystemApplication {
	
	private static PatientService patientService;

	public static void main(String args[]) throws ParseException {
		ApplicationContext context = SpringApplication.run(PatientIntakeSystemApplication.class, args);
		SpringApplication.run(PatientIntakeSystemApplication.class, args);
		log.info("Main method");
		context.getBean(PatientAppointment.class);
		context.getBean(ClinicCalender.class);
		testAddAppointment();
		testviewAppointment();
	}

	private static void testAddAppointment() throws ParseException {
		
		log.info("add appointment method called");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		PatientAppointment p = new PatientAppointment();
		p.setName("XYZ");
		p.setAppointmentDate(format.parse("2020-03-24"));
		ClinicCalender c= new ClinicCalender();
		patientService.addAppointment(c, p);
		log.info("End of add appointment method");
		
	}

	private static void testviewAppointment() {
		// TODO Auto-generated method stub
		log.info("view appointments method called");
		ClinicCalender c= new ClinicCalender();
		patientService.viewAllAppointment(c);
		log.info("view appointments method end");
		
		

	}

}
