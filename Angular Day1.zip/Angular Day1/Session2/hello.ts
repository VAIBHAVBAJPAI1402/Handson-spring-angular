//interface
interface User {
    name: string;
    id: number;
  }
  
  class UserAccount {
    name: string;
    id: number;
  
    constructor(name: string, id: number) {
      this.name = name;
      this.id = id;
    }
  }
  //object of type User
  const user: User = new UserAccount("Murphy", 1);