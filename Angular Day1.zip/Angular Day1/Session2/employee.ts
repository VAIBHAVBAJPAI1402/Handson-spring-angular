import {Department} from "./department";
import {Skill} from "./skills";
export interface Employee{
    id:number,
    name:String,
    salary:number,
    permanent:boolean,
    dept:Department,
    skill:Skill[]
}
