"use strict";
exports.__esModule = true;
var EmployeeTest = /** @class */ (function () {
    function EmployeeTest(obj) {
        this.employee = obj;
    }
    EmployeeTest.prototype.display = function () {
        console.log("id : " + this.employee.id);
        console.log("name : " + this.employee.name);
        console.log("salary : " + this.employee.salary);
        console.log("permanent : " + this.employee.permanent);
        console.log("Department id:" + this.employee.dept.id);
        console.log("Department name:" + this.employee.dept.name);
        console.log(skillArray);
    };
    return EmployeeTest;
}());
var dept = { id: 101, name: "HR" };
var skillArray = [{ id: 201, name: "HTML" }, { id: 202, name: "CSS" }, { id: 203, name: "JavaScript" }];
var obj = {
    id: 101,
    name: "Vaibhav",
    salary: 5000,
    permanent: true,
    dept: {
        id: 101,
        name: "HR"
    },
    skill: [{ id: 201, name: "HTML" }, { id: 202, name: "CSS" }]
};
var employee1 = new EmployeeTest(obj);
console.log(employee1.display());
