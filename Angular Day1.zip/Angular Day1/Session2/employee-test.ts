import { Department } from "./department";
import { Employee } from "./employee";
import { Skill } from "./skills";
class EmployeeTest{
    employee:Employee;
    constructor(obj:Employee){
       this.employee=obj;
    }
    display(){
        console.log("id : "+this.employee.id);
        console.log("name : "+this.employee.name);
        console.log("salary : "+this.employee.salary);
        console.log("permanent : "+this.employee.permanent);
        console.log("Department id:"+this.employee.dept.id);
        console.log("Department name:"+this.employee.dept.name);
        console.log(skillArray);
    }
}
var dept:Department={id:101,name:"HR"};
var skillArray=[{id:201,name:"HTML"},{id:202,name:"CSS"},{id:203,name:"JavaScript"}];
var obj:Employee={
    id:101,
    name:"Vaibhav",
    salary:5000,
    permanent:true,
    dept:{
        id:101,
        name:"HR"
    },
    skill:[{id:201,name:"HTML"}, {id:202,name:"CSS"}]
};
var employee1=new EmployeeTest(obj);
console.log(employee1.display());
