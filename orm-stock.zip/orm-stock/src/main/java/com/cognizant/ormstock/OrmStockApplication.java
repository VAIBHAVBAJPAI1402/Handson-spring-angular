package com.cognizant.ormstock;

import java.util.List;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.ormstock.model.Stock;
import com.cognizant.ormstock.repository.StockRepository;
import com.cognizant.ormstock.service.StockService;

import org.slf4j.Logger;

@SpringBootApplication
public class OrmStockApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(OrmStockApplication.class);

	@Autowired
	private static StockService service;

	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(OrmStockApplication.class);
		//testStockByGivenMonthOfYear();
		service=ctx.getBean(StockService.class);
		testFindByStockCode();
	}

	// handson-2 stock table
	/*private static void testStockByGivenMonthOfYear() {
		List<Stock> stocks = stockRepository.findByGivenDate("09", "2019");
		for (Stock obj : stocks)
			System.out.println(obj);

	}*/
	
	private static void testFindByStockCode() {
		service.findByGivenCode("NFLX");
		
	}
}
