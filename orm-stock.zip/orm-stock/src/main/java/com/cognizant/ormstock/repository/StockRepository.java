package com.cognizant.ormstock.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cognizant.ormstock.model.Stock;

public interface StockRepository extends JpaRepository<Stock, Integer>{

	/*@Query(value="Select * from stock where st_date.MONTH=?1 AND st_date.YEAR=?2 ", nativeQuery = true)
	List<Stock> findByGivenDate(String month, String year);*/
	
	@Query(value = "Select * from stock where st_code=?1", nativeQuery = true)
	List<Stock> findByCode(String code);
}
