package com.cognizant.ormstock.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormstock.model.Stock;
import com.cognizant.ormstock.repository.StockRepository;
@Service
public class StockService {
	@Autowired
	private StockRepository repository;
	
	@Transactional
	public void findByGivenCode(String str) {
		List<Stock> lst=repository.findByCode(str);
		for(Stock s:lst) {
			System.out.println(s);
		}
	}
}
