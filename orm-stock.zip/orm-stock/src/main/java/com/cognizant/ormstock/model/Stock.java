package com.cognizant.ormstock.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "stock")
public class Stock {

	@Id
	@GeneratedValue
	@Column(name = "st_id")
	private int st_id;

	@Column(name = "st_code")
	private String code;

	@Column(name = "st_date")
	private Date st_date;

	@Column(name = "st_open")
	private float st_open;

	@Column(name = "st_close")
	private float st_close;

	@Column(name = "st_volume")
	private long st_volumne;

	public int getSt_id() {
		return st_id;
	}

	public void setSt_id(int st_id) {
		this.st_id = st_id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String st_code) {
		this.code = st_code;
	}

	public Date getSt_date() {
		return st_date;
	}

	public void setSt_date(Date st_date) {
		this.st_date = st_date;
	}

	public float getSt_open() {
		return st_open;
	}

	public void setSt_open(float st_open) {
		this.st_open = st_open;
	}

	public float getSt_close() {
		return st_close;
	}

	public void setSt_close(float st_close) {
		this.st_close = st_close;
	}

	public long getSt_volumne() {
		return st_volumne;
	}

	public void setSt_volumne(long st_volumne) {
		this.st_volumne = st_volumne;
	}

	public Stock() {
		super();
	}

	public Stock(String st_code, Date st_date, float st_open, float st_close, long st_volumne) {
		super();
		this.code = st_code;
		this.st_date = st_date;
		this.st_open = st_open;
		this.st_close = st_close;
		this.st_volumne = st_volumne;
	}

}
