package com.cognizant.flight;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.ApplicationContext;

import com.cognizant.flight.model.Flight;
import com.cognizant.flight.model.Passenger;
import com.cognizant.flight.service.FlightService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class })
public class FlightManagementApp {
	private static FlightService flightService;

	public static void main(String args[]) {
		ApplicationContext context = SpringApplication.run(FlightManagementApp.class, args);
		log.info("Main method called");
		context.getBean(Flight.class);
		context.getBean(Passenger.class);
		testAddPassenger();
		testRemovePassenger();
	}

	public static void testAddPassenger() {
		log.info("Start adding passenger");
		Passenger p = new Passenger();
		p.setName("Shashwat");
		p.setVip(true);
		flightService.addPassenger(p);
		log.info("End add passsenger method");
	}

	public static void testRemovePassenger() {
		log.info("Start remove passenger");
		Passenger p = new Passenger();
		flightService.removePassenger(p);
		log.info("End remove passenger method");

	}

}
