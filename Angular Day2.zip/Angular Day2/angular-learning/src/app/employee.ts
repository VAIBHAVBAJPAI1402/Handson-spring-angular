import {Department} from "./department";
import {Skill} from "./Skill";
export interface Employee{
    id:number,
    name:String,
    salary:number,
    permanent:boolean,
    dept:Department,
    skills:Skill[]
}