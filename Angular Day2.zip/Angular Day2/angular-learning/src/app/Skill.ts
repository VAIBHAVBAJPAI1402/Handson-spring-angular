export interface Skill{
    id:number,
    name:String
}