import { Department } from "./department";
import {Employee} from "./employee";
import { Skill } from "./Skill";
export class EmployeeTest implements Employee{
    id: number;
    name: String;
    salary: number;
    permanent: boolean;
    dept: Department;
    skills: Skill[];
    dateOfBirth:Date;
    constructor(){
        this.id=3;
        this.name="John";
        this.salary=10000;
        this.permanent=true;
        this.dept={id:101,name:"HR"};
        this.skills=[{id:1,name:"HTML"},{id:2,name:"CSS"},{id:3,name:"JavaScript"}];
        this.dateOfBirth=new Date('12/31/2000');
    }
    
}