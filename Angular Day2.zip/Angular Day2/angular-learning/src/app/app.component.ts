import { Component } from '@angular/core';
import { Department } from './department';
import { Employee } from './employee';
import { Skill } from './Skill';
import {EmployeeTest} from "./employeeTest";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent{
  title = 'angular-learning';
  //favourite_movie="Lord of the Rings";
  emp:EmployeeTest = new EmployeeTest(); 
}
