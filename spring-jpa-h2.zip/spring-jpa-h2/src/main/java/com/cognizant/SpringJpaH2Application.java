package com.cognizant;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.model.Employee;
import com.cognizant.service.EmployeeService;

import lombok.extern.apachecommons.CommonsLog;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class SpringJpaH2Application {

	

	private static EmployeeService service;

	public static void main(String[] args) {
		log.info("Start");
		ApplicationContext context = SpringApplication.run(SpringJpaH2Application.class, args);
		service = context.getBean(EmployeeService.class);
		testaddEmployee();
		testFindAll();
		findByName();
		log.info("End of main");
	}

	private static void testaddEmployee() {
		service.save(new Employee(101L, "Rahul"));
		service.save(new Employee(102L, "Ashish"));
		service.save(new Employee(103L, "Piysh"));
	}

	private static void testFindAll() {
		log.info("finding employee data");
		List<Employee> employees=service.findAll();
		for(Employee e:employees)
		{
			System.err.println(e);
		}
		
		log.info("Ending findall method");
		
	}
	
	private static void findByName() {
		List<Employee> employees=service.findEmployeesByName();
		for(Employee e:employees)
		{
			System.err.println(e);
		}
		
		log.info("Ending findby Name method");
	}

}
