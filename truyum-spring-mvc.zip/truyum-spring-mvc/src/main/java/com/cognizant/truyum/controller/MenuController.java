package com.cognizant.truyum.controller;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;

public class MenuController {

	@Autowired
	private MenuItemService menuitemservice;
	
	private static final Logger LOGGER=LoggerFactory.getLogger(MenuController.class);
	
	@GetMapping(value = "/show-menu-list-admin")
	public String showMenuItemListAdmin(ModelMap model) throws SystemException{
		LOGGER.info("show menu item list method called");
		model.addAttribute(menuitemservice.getMenuItemListAdmin());
		LOGGER.info("End");
		return "menu-item-list-admin";
	}
}
