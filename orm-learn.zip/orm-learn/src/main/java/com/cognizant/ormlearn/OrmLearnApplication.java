package com.cognizant.ormlearn;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.StaticApplicationContext;

import com.cognizant.ormlearn.exception.CountryCodeNotFoundException;
import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.model.Department;
import com.cognizant.ormlearn.model.Employee;
import com.cognizant.ormlearn.service.CountryService;
import com.cognizant.ormlearn.service.DepartmentService;
import com.cognizant.ormlearn.service.EmployeeService;
import com.cognizant.ormlearn.service.SkillService;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

@SpringBootApplication
public class OrmLearnApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);
	private static CountryService countryService;
	private static EmployeeService employeeService;
	private static SkillService skillService;
	private static DepartmentService departmentService;

	public static void main(String[] args) throws ParseException {
		// creating the service bean - Handson 1
		ApplicationContext ctx = SpringApplication.run(OrmLearnApplication.class, args);
		countryService = ctx.getBean(CountryService.class);
		employeeService = ctx.getBean(EmployeeService.class);
		skillService = ctx.getBean(SkillService.class);
		departmentService = ctx.getBean(DepartmentService.class);

		testGetCountryByCode();

		testAddNewCountry();

		testUpdateCountry();

		testDeleteCountry();

		testGetAllCountries();

		testGetSortedCountriesByName();

		/*
		 * SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd"); Date d1=(Date)
		 * format.parse("2019-09-03");
		 */
		testCountryByGivenString();

		testCountryByCodeStartingWith();

		//testGetEmployee();
		testAddEmployee();
		
	}
	
	@SuppressWarnings("deprecation")
	private static void testAddEmployee() {

		LOGGER.info("Start");

		Employee employee = new Employee();
		employee.setId(2);
		employee.setName("Vipin");
		employee.setPermanent(true);
		employee.setSalary(50000);
		employee.setDateOfBirth(new Date(2000, 8, 7));
		Department objDepartment=new Department(5,"xyz");
		departmentService.addDepartment(objDepartment);
		employee.setDepartment(departmentService.getById(5));

		System.out.println(employeeService.addEmployee(employee));
		LOGGER.debug("Employee:{}", employee);

		LOGGER.info("End");

		}

	private static void testGetEmployee() {

		LOGGER.info("Start");
		Employee employee = employeeService.getById(1);
		LOGGER.debug("Employee:{}", employee);
		LOGGER.debug("Department:{}", employee.getDepartment());
		LOGGER.info("End");

	}

	// get all countries - Handson 5
	private static void testGetAllCountries() {
		LOGGER.info("Start");
		List<Country> countries = countryService.getAllCountries();
		LOGGER.debug("countries={}", countries);
		LOGGER.info("End");
	}

	// get country by code- Handson 6
	private static void testGetCountryByCode() {
		try {
			Country country = countryService.getCountryByCode("IN");
			LOGGER.debug("country=", country);
		} catch (CountryCodeNotFoundException e) {
			// TODO: handle exception
			LOGGER.info(e.getMessage());
		}
	}

	// add a new country - Handson 7
	private static void testAddNewCountry() {
		Country obj = new Country("EG", "England");
		countryService.addCountry(obj);
		LOGGER.info("Country added");

	}

	// update country based on code - Handson 8
	private static void testUpdateCountry() {
		countryService.updateCountryOnCode("EG");
		LOGGER.info("Update method was called");
	}

	// delete country based on code - Handson 9
	private static void testDeleteCountry() {
		countryService.deleteCountryOnCode("EG");
		LOGGER.info("Country deleted");
	}

	private static void testGetSortedCountriesByName() {
		countryService.findCountrySortedByName();
		LOGGER.info("sorting was completed");
	}

	// day2 handson 1
	private static void testCountryByGivenString() {

		countryService.getCountriesBySubstring("an");
		LOGGER.info("substring method called");
	}

	// day 2 hanson 1
	private static void testCountryByCodeStartingWith() {
		countryService.getCountryNameContainingCode("B");
		LOGGER.info("searched code containg code substring b");
	}
}
