package com.cognizant.ormlearn.service;


import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.model.Department;
import com.cognizant.ormlearn.repository.DepartmentRepository;

import javax.transaction.Transactional;

import org.slf4j.Logger;

@Service
public class DepartmentService {
	private static final Logger LOGGER=LoggerFactory.getLogger(DepartmentService.class);
	@Autowired
	private static DepartmentRepository departmentRepository;
	
	@Transactional
	public Department getById(int id) {
		LOGGER.info("find by id method");
		return departmentRepository.findById(id).get();
	}
	
	@Transactional
	public void addDepartment(Department department) {
		departmentRepository.save(department);
	}
}
