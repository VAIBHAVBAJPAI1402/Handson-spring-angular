package com.cognizant.ormlearn.service;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.model.Employee;
import com.cognizant.ormlearn.repository.EmployeeRepository;

@Service
public class EmployeeService {
	@Autowired
	private static EmployeeRepository employeeRepository;
	private static final Logger LOGGER=LoggerFactory.getLogger(DepartmentService.class);
	
	@Transactional
	public Employee getById(int id) {
		LOGGER.info("find by id method");
		return employeeRepository.findById(id).get();
	}
	
	@Transactional
	public int addEmployee(Employee employee) {
		
		employeeRepository.save(employee);
		LOGGER.info("employee added");
		return 1;
	}
}
