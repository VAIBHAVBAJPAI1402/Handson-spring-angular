package com.cognizant.ormlearn.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.model.Department;
import com.cognizant.ormlearn.model.Skill;
import com.cognizant.ormlearn.repository.DepartmentRepository;
import com.cognizant.ormlearn.repository.EmployeeRepository;
import com.cognizant.ormlearn.repository.SkillRepository;

@Service
public class SkillService {
	@Autowired
	private static SkillRepository skillRepository;
	private static final Logger LOGGER=LoggerFactory.getLogger(DepartmentService.class);

	
	public Skill getById(int id) {
		LOGGER.info("find by id method");
		return skillRepository.findById(id).get();
	}
	
	public void addSkill(Skill skill) {
		
		skillRepository.save(skill);
		LOGGER.info("skill added");
	}
}
