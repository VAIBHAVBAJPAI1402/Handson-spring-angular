package com.cognizant.ormlearn.exception;

public class CountryCodeNotFoundException extends Exception{

}
