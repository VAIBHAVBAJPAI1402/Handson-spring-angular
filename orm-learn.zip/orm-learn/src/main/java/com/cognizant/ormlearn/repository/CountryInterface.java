package com.cognizant.ormlearn.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.ormlearn.model.Country;
import java.util.List;

public interface CountryInterface extends JpaRepository<Country, String>{
	List<Country> findByNameLike(String name);
	
	List<Country> findByNameEndingWith(String suffix);
	
	List<Country> findByNameContaining(String substring);
	
	List<Country> findByCodeStartingWith(String prefix);
}
