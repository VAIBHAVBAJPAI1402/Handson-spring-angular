package com.cognizant.ormlearn.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.exception.CountryCodeNotFoundException;
import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.repository.CountryInterface;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

@Service
public class CountryService {
	@Autowired
	private CountryInterface repository;
	
	@Transactional
	public List<Country> getAllCountries(){
		return repository.findAll();
	}
	
	@Transactional
	public Country getCountryByCode(String code) throws CountryCodeNotFoundException{
		Optional<Country> result=repository.findById(code);
		if(!result.isEmpty())
		{
			Country country=result.get();
			return country;
		}
		return null;
	}
	
	@Transactional
	public void addCountry(Country country) {
		repository.save(country);
	}
	
	@Transactional
	public void updateCountryOnCode(String code) {
		Optional<Country> result=repository.findById(code);
		if(!result.isEmpty()) {
			Country country=result.get();
			country.setName("Egypt");
			repository.save(country);
		}
		
	}
	
	@Transactional
	public void findCountrySortedByName() {
		List<Country> countries=repository.findByNameEndingWith("n");
		for(Country c:countries)
			System.out.println(c);
	}
	
	@Transactional
	public void deleteCountryOnCode(String code) {
		Optional<Country> result=repository.findById(code);
		if(!result.isEmpty()) {
			Country country=result.get();
			repository.delete(country);
		}
	}
	
	@Transactional
	public void getCountriesBySubstring(String str) {
		List<Country> result=repository.findByNameContaining(str);
		if(!result.isEmpty()) {
			for(Country c:result) {
				System.out.println(c);
			}
		}
	}
	
	@Transactional
	public void getCountryNameContainingCode(String str) {
		List<Country> result=repository.findByCodeStartingWith(str);
		if(!result.isEmpty()) {
			for(Country c:result) {
				System.out.println(c);
			}
		}
	}
}
