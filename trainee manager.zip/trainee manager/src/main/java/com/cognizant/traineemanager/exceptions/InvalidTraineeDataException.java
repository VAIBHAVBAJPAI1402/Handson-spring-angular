package com.cognizant.traineemanager.exceptions;

public class InvalidTraineeDataException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidTraineeDataException(String message) {
		super(message);
	}
}
