# TraineeManager_HandsOn-02 
## >Lombok and SONAR handsOn 02
## >In this we needed to create a Menu Driven Application
## >That is why no JUnit Test case is written for that application.
## >Having 0 Code Smells and  0 Bugs(Tested on SonarQube)
